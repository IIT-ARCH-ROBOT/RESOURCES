https://community.spark.io/t/installing-the-usb-driver-on-windows-serial-debugging/882
